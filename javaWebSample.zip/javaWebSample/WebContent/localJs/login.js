$(document).ready(function() {
	var loginMsg = $('#loginMsg').val();
	alert(loginMsg);
	if (loginMsg == "NG") {
		alert("ユーザー又はパスワードが不正。");
	}
    /**
     * 下面是进行插件初始化
     * 你只需传入相应的键值对
     * */
	alert('1');
    $('#loginForm').bootstrapValidator({
            message: 'This value is not valid',
            feedbackIcons: {/*输入框不同状态，显示图片的样式*/
                valid: 'glyphicon glyphicon-ok',
                invalid: 'glyphicon glyphicon-remove',
                validating: 'glyphicon glyphicon-refresh'
            },
            fields: {/*验证*/
                username: {/*键名username和input name值对应*/
                    message: 'The username is not valid',
                    validators: {
                        notEmpty: {/*非空提示*/
                            message: '用户名不能为空'
                        }
                    }
                },
                password: {
                    message:'密码无效',
                    validators: {
                        notEmpty: {
                            message: '密码不能为空'
                        }
                    }
                }
            }
        });
});
