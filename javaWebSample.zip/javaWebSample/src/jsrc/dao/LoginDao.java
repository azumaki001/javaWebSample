package jsrc.dao;

import java.util.HashMap;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;

public class LoginDao {

	SqlSession session = null;
	SqlSessionFactory factory = SingtonFactory.getFactory();

	public boolean checkLogin (String user, String pwd) {
		Object result = null;
		try {
			session = factory.openSession();

			Map<String,Object> paramMap = new HashMap<String,Object> ();
			paramMap.put("user", user);
	        paramMap.put("pwd", pwd);
			result = session.selectOne("seisan.rest.mysql.SELECT_USER_PWD", paramMap);
		} finally {
			session.close();
		}

		if (result == null) {
			return false;
		}
		return true;
	}
}
