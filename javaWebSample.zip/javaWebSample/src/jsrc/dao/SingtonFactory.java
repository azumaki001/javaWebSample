package jsrc.dao;

import java.io.InputStream;

import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

public class SingtonFactory {

    private static SqlSessionFactory factory = null;

	private SingtonFactory(){}

    public static SingtonFactory getInstace() {
        return SingletonHolder.INSTANCE;
    }

    private static class SingletonHolder {
        private static final SingtonFactory INSTANCE = new SingtonFactory();
    }

    public static SqlSessionFactory getFactory () {
        if (factory != null) {
            return factory;
        }
        InputStream in = SingtonFactory.class.getResourceAsStream("../../resources/mybatis-config.xml");
        factory = new SqlSessionFactoryBuilder().build(in);
        return factory;
    }
}
