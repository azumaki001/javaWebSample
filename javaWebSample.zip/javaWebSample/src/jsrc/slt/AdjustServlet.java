package jsrc.slt;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class AdjustServlet extends HttpServlet {

	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
    {
//		doPost(req, resp);
		String name = (String) req.getAttribute("userName");
		if (name == null) {
			name = (String) req.getParameter("userName");
		}
		RequestDispatcher rd = req.getRequestDispatcher("/adjust.jsp");
		req.setAttribute("userName", name);
		rd.forward(req, resp);
	}

	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
    {
		String name = (String) req.getAttribute("userName");
		if (name == null) {
			name = (String) req.getParameter("userName");
		}
		RequestDispatcher rd = req.getRequestDispatcher("/adjust.jsp");
		req.setAttribute("userName", name);
		rd.forward(req, resp);
	}
}
