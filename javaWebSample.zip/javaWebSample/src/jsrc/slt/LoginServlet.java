package jsrc.slt;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import jsrc.dao.LoginDao;
import jsrc.fil.TokenManagement;

public class LoginServlet extends HttpServlet {

	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
    {
		doPost(req, resp);
	}

	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException
    {
		RequestDispatcher rd = null;

		String name = (String) req.getParameter("userName");
		String pwd = (String) req.getParameter("userPassword");

//		if (name == null) {
//			name = "";
//		}
//		if (pwd == null) {
//			pwd = "";
//		}
		LoginDao ld = new LoginDao ();

		if (!ld.checkLogin(name, pwd)) {
			req.setAttribute("result", "NG");
			rd = req.getRequestDispatcher("/login.jsp");
		} else {
			TokenManagement tm = TokenManagement.getInstace();
			String tokenId = tm.generateAndStore();

			HttpSession session = req.getSession();
			session.setAttribute("701seisan", tokenId);

			Cookie cookie = new Cookie("701seisan", tokenId);
			cookie.setMaxAge(3600*24*3);
			resp.addCookie(cookie);

			tm.setWebCookies(tokenId, name);

			req.setAttribute("userName", name);

			rd = req.getRequestDispatcher("/main.ac");
		}

		rd.forward(req, resp);
	}
}
