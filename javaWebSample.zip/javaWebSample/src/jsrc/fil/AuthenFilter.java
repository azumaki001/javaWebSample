package jsrc.fil;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class AuthenFilter implements Filter {

	@Override
	public void destroy() {
		// TODO 自動生成されたメソッド・スタブ

	}

	@Override
	public void doFilter(ServletRequest req, ServletResponse res, FilterChain fc) throws IOException, ServletException {

		HttpServletRequest httpreq = (HttpServletRequest)req;
		HttpServletResponse httpres = (HttpServletResponse) res;

		TokenManagement tm = TokenManagement.getInstace();

		String tokenId = (String) httpreq.getSession().getAttribute("701seisan");
		if (tokenId == null || "".equals(tokenId)) {
			Cookie[] cookies = httpreq.getCookies();
			if (cookies != null) {
				for (Cookie ck : cookies) {
					if ("701seisan".equals(ck.getName())) {
						tokenId  = ck.getValue();
					}
				}
			}
		}

		RequestDispatcher rd = null;
		if(tm.check(tokenId)) {
			String userName = (String) tm.getWebCookies(tokenId);
			httpreq.setAttribute("userName", userName);
			fc.doFilter(httpreq, httpres);
		} else {
			rd = httpreq.getRequestDispatcher("/login.jsp");
			rd.forward(httpreq, httpres);
		}
	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {

	}
}
